#!/usr/bin/env python3
import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest_path=root/'FCO_PAYLOAD_MANIFEST.sha256'
seal=json.loads((root/'FCO_SEAL.json').read_text())
failures=[]
for line in manifest_path.read_text().splitlines():
    expected, rel=line.split('  ',1)
    p=root/rel
    if not p.is_file():
        failures.append(f'MISSING {rel}')
        continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual != expected:
        failures.append(f'HASH_MISMATCH {rel}')
manifest_hash=hashlib.sha256(manifest_path.read_bytes()).hexdigest()
if manifest_hash != seal['manifest_sha256']:
    failures.append('MANIFEST_HASH_MISMATCH')
pdf_hash=hashlib.sha256((root/'payload/paper.pdf').read_bytes()).hexdigest()
if pdf_hash != seal['paper_pdf_sha256']:
    failures.append('PAPER_HASH_MISMATCH')
if failures:
    print('\n'.join(failures))
    raise SystemExit(1)
print('FCO_SEAL_VERIFY=PASS')
print('manifest_sha256='+manifest_hash)
print('paper_pdf_sha256='+pdf_hash)
