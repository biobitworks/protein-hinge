# Reviewer verification — DRM-free anonymous submission seal

This bundle is content-addressed, not encrypted and not access-controlled.
Verification does not require network access.

1. Run `python3 verify.py` from this directory.
2. The verifier recomputes SHA-256 for every payload leaf listed in
   `FCO_PAYLOAD_MANIFEST.sha256`.
3. It recomputes the SHA-256 of the manifest itself and compares it
   with `FCO_SEAL.json`.
4. `payload/paper.pdf` is the exact anonymous paper leaf sealed by this bundle.

This is a minimal anonymous submission profile. It does not claim an
Ed25519 signature, Merkle/MMR construction, or conformance with any
separately published FCO protocol version. The seal proves byte identity
and manifest closure only; it does not prove biological truth, therapeutic
efficacy, or correctness of every scientific inference.
